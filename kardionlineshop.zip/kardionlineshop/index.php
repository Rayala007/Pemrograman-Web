<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>	ADMIN</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/Google-Style-Login.css">
</head>

<body>
    <div class="login-card"><img src="assets/img/avatar_2x.png" class="profile-img-card">
        <p class="profile-name-card"> </p>
        <form class="form-signin" method="post" action="database/loginadmin.php"><span class="reauth-email"> ADMIN</span>
            <input class="form-control name" type="name"  placeholder="username" name="name">
            <input class="form-control" type="password"  placeholder="password"  name="pass">
    
            <button class="btn btn-primary btn-block btn-lg btn-primary" type="submit" value="LOGIN" name="login">Sign in</button>
        </form>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>
</html>

<?php
	class admin{

		function formlogin(){
			return"<form method='post' action='database/loginadmin.php'>
            	</form>";
		}
	}

	$ad = new admin();
	echo $ad->formlogin();

?>