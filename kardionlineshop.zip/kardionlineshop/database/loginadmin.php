<?php

include("koneksi.php");

if(isset($_POST['login']))
{
    $username=$_POST['name'];
    $passadmin=$_POST['pass'];

    if($username=='')
    {
        echo"<script>alert('Masukan username !!')</script>";
        echo"<script>window.open('../index.php','_self')</script>";
exit();
    }
    if($passadmin=='')
    {
        echo"<script>alert('Masukan password !!')</script>";
        echo"<script>window.open('../index.php','_self')</script>";
exit();
	}

    $check_admin="select * from admin WHERE username='$username' AND passadmin='$passadmin'";

    $run=mysqli_query($dbcon,$check_admin);

    if(mysqli_num_rows($run))
    {
        echo "<script>window.open('../objek/pilihkelola.php','_self')</script>";

        $_SESSION['name']=$username;

    }
}
?>