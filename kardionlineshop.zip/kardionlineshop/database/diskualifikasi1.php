<?php
include("koneksi.php");

$delete_id=$_GET['del'];
$delete_query="delete  from kursi1 where id_pelanggan='$delete_id'";
$run=mysqli_query($dbcon,$delete_query);
if($run)
{
    echo "<script>window.open('../objek/pilihkelola.php','_self')</script>";
}

?>