<?php
include("koneksi.php");
if(isset($_POST['post']))
{
    $nama_pelanggan=$_POST['merk'];
    $alamat_pelanggan=$_POST['harga'];
    $hp_pelanggan=$_POST['stok'];
    $jk_pelanggan=$_POST['jk'];
    $tanggal=date('l, d-m-Y');
    $jam=$_POST['genre'];

    if($nama_pelanggan=='')
    {
        echo"<script>alert('Isi Merk Pakaian !!')</script>";
        echo"<script>window.open('../objek/kursi1.php','_self')</script>";
exit();
    }

    if($alamat_pelanggan=='')
    {
        echo"<script>alert('Masukan Harga Pakaian !!')</script>";
        echo"<script>window.open('../objek/kursi1.php','_self')</script>";
exit();
    }

    if($hp_pelanggan=='')
    {
        echo"<script>alert('Stok Belum Diisi !!')</script>";
        echo"<script>window.open('../objek/kursi1.php','_self')</script>";
    exit();
    }
    if($jk_pelanggan=='')
    {
        echo"<script>alert('Kategori Belum dipilih !!')</script>";
        echo"<script>window.open('../objek/kursi1.php','_self')</script>";
    exit();
    }
    
    $insert_pelanggan="insert into kursi1 (id_pelanggan,nama_pelanggan,alamat_pelanggan,hp_pelanggan,jk_pelanggan,tanggal,jam) VALUE ('','$nama_pelanggan','$alamat_pelanggan','$hp_pelanggan','$jk_pelanggan','$tanggal','$jam')";
    if(mysqli_query($dbcon,$insert_pelanggan))
    {
        echo"<script>alert('Berhasil !')</script>";

        echo"<script>window.open('../objek/pilihkelola.php','_self')</script>";
    }

}
?>