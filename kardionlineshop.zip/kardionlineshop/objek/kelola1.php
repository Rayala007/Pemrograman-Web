<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>kelola1</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body>
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <td align="center"><b>Kode Produk</b></td>
                    <td align="center"><b>Merk</b></td>
                    <td align="center"><b>Harga</b></td>
                    <td align="center"><b>Stok</b></td>
                    <td align="center"><b>Kategori</b></td>
                    <td align="center"><b>Tanggal Post</b></td>
                    <td align="center"><b>Genre</b></td>
                    <td align="center"><b>Lain-lain</b></td>
                </tr>
            </thead>
            <tbody>
                 <tr>
                        <?php
                            include('../database/koneksi.php');
                                $tampil_laporan_query="select * from kursi1";
                                $run=mysqli_query($dbcon,$tampil_laporan_query);

                                while($row=mysqli_fetch_array($run))
                                {
                                    $id_pelanggan=$row[0];
                                    $nama=$row[1];
                                    $alamat=$row[2];
                                    $hp=$row[3];
                                    $jk=$row[4];
                                    $tanggal=$row[5];
                                    $jam=$row[6];
                        ?>

                                    <td  align="center"><? echo $id_pelanggan; ?></td>
                                    <td  align="center"><? echo $nama; ?></td>
                                    <td  align="center">Rp.<? echo $alamat; ?></td>
                                    <td  align="center"><? echo $hp; ?></td>
                                    <td  align="center"><? echo $jk; ?></td>
                                    <td  align="center"><? echo $tanggal; ?></td>
                                    <td  align="center"><? echo $jam; ?></td>
                                    <td align="center" ><a href="../database/diskualifikasi1.php?del=<?php echo $id_pelanggan; ?>">
                                    <button class="btn btn-default btn-xs" >Hapus</button></a></td>
                                </tr>
                   <?php } ?>
            </tbody>
        </table>
    </div>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>