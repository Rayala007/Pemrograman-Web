<?php 
$tgl=date('l, d-m-Y');
    echo $tgl;
    echo"<i> [Online]</i>";
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>form</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body>
    <div class="form-group"></div>
    <form class="bootstrap-form-with-validation" method="post" action="../database/simpandata1.php" >
        <h2 class="text-center">Tambahkan Pakaian Baru</h2>
        <div class="form-group">
            <label class="control-label" for="text-input">Merk</label>
            <input class="form-control" type="text" name="merk">
        </div>
		<div class="form-group">
            <label class="control-label" for="text-input">Harga</label>
            <input class="form-control" type="text" name="harga">
        </div>
		<div class="form-group">
            <label class="control-label" for="text-input">Stok</label>
            <input class="form-control" type="text" name="stok">
        </div>
		<div class="form-group">
			<label class="control-label" for="text-input">Kategori</label><br>
                    <input type="radio" name="jk" value="Inner"> Inner<br>
					<input type="radio" name="jk" value="Basewear"> Basewear<br>
                     <input type="radio" name="jk" value="Outifit"> Outfit<br></label>
            </div>
        </div>
		<div class="form-group">
			<label class="control-label" for="text-input">Pilih Genre</label>
			<select name='genre' class="form-control">
        		<option type='radio'>Pakaian Wanita</option>
        		<option type='radio'>Pakaian Pria</option>
        		
         </select><br>
		 <div>
		 <button class="btn btn-default" type="submit" value="post" name="post">POST</button>
		 </div>
</body>
</html>

<?php
class kursi1{
    function tampilform(){
        return"<form method='post' action='../database/simpandata1.php'>
    	          
		      </form>";
    }
   
    function contact(){
        return"<center>================================================================<br>
                
                </center>";
    }
}
    $kur1 = new kursi1();
    echo"<br>";
    echo $kur1->tampilform();
   
    echo"<br>";
    
    echo $kur1->contact();
?>